// Stopwatch program V0.2
// Written by John Robinson for Didier R.
// 6th November 2022

// #include "Arduino.h"
#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#include <Fonts/FreeSans24pt7b.h>
#include <Fonts/FreeSans18pt7b.h>
#include <Fonts/FreeSans12pt7b.h>
#include <Fonts/FreeSans9pt7b.h>

#include <Battery.h>

// We just have one push button (later to be replaced by a touch pad)
// Since we have 3 actions for the button press, we need to set up a simple state-machine. 
// The program starts in the state BUTTON_STATE_RESET, and the display is set to all zeros
// On the first press, the state changes to BUTTON_STATE_START, and the stopwatch starts counting
// On the second press, the state changes to BUTTON_STATE_STOP, the stopwatch stops, and the display
// shows the finish time.
// On the third press, the stop watch is reset to all zeros, ready to start the process over again
#define   BUTTON_STATE_START    0
#define   BUTTON_STATE_STOP     1

#define   BUTTON_GPIO_PIN       16
#define   BUTTON_DEBOUNCE_TIME  250

#define   BATTERY_VOLTAGE_PIN   33

Battery battery(3200, 4200, BATTERY_VOLTAGE_PIN);

unsigned long last_battery_check;
#define   BATTERY_CHECK_INTERVAL  30000

// These variables track the current state of the state-machine
int button_state;
volatile int button_pressed;
unsigned long last_button_press;

struct current_state_t
{
  unsigned long start_time;
  unsigned long stop_time;
  unsigned long time_stamp;
  int current_button_state;
  float battery_voltage;
}; 

// We just need to declare the functions that we created in the program.
void error_message (String);
void button_press (void);
void display_time (current_state_t);
void millis_to_time (char *, unsigned long);
// float read_battery_voltage (void);
void display_battery_percentage (void);
void draw_battery (int x, int y, int battery_width, int battery_height, int battery_percentage);

#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels

// Declaration for an SSD1306 display connected to I2C (SDA, SCL pins)
// The pins for I2C are defined by the Wire-library. 
// On an arduino UNO:       A4(SDA), A5(SCL)
// On an arduino MEGA 2560: 20(SDA), 21(SCL)
// On an arduino LEONARDO:   2(SDA),  3(SCL), ...
#define OLED_RESET     -1 // Reset pin # (or -1 if sharing Arduino reset pin)
#define SCREEN_ADDRESS 0x3C ///< See datasheet for Address; 0x3D for 128x64, 0x3C for 128x32
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// All Arduino programs must have two functions present. The first is called "setup", and it is called just 
// once at the start of the program. The other is called "loop" (see below) which just loops over and over 
// doing whatever it is meant to do

void setup() {
  Serial.begin (9600);
  // First, we need to initialise the display
    // SSD1306_SWITCHCAPVCC = generate display voltage from 3.3V internally
  if(!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
    Serial.println(F("SSD1306 allocation failed"));
    for(;;); // Don't proceed, loop forever
  }

  display.setFont(&FreeSans24pt7b);
  display.display();

  // And we need to set the state machine to that it starts in the BUTTON_STATE_RESET state. This will
  // cause the display to be set to all zeros.
  button_state = BUTTON_STATE_STOP;
  last_button_press = 0;
  button_pressed = false;

  // NEED TO ASSIGN AN INTERUPT FOR THE BUTTON_PRESS
  // There are 2 ways that we can check to see if the button has been pressed. 
  // The simplest way is called "Polling", where we continuously check the button imput to see if it has been pressed. 
  // This is inefficient, and could result in us missing a button press. 
  // The better way is to make the button "Interupt Driven", we can configure the processor so that when the 
  // Button is pressed, it will interrupt the processor from what it is doing, and make it take action for the 
  // button press. We need to set up an Interrupt here to call the function "button_press()" (see below)
  // whenever the button is pressed. 
  pinMode (BUTTON_GPIO_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(BUTTON_GPIO_PIN), button_press, HIGH);

  delay (BUTTON_DEBOUNCE_TIME);

  Serial.print("CPU Freq: ");
  Serial.println(getCpuFrequencyMhz());
 
  setCpuFrequencyMhz(40);
 
  Serial.print("CPU Freq: ");
  Serial.println(getCpuFrequencyMhz()); 

  battery.begin (3300, 1.47, &sigmoidal);
  display_battery_percentage ();
  last_battery_check = millis();
}

// This is the start of the main loop
// The arduino has an inbuilt clock, and it just starts counting milliseconds since the arduino was powered up. 
// The count will last for around 50 days before it is reset to zero, but we have not catered for this happening
// as it is unlikely that a stopwatch will be used to time something greater than 50 days.
// To find the current count of milliseconds, we just call the standard arduino function called millis()

void loop() {
  // At the start, the button state will be BUTTON_STATE_RESET, so we will set the start time and stop time to zero.
  // We don't really need to do this, but it is considered good practice.
  static current_state_t current_state = {0, 0, 0, button_state};  
  static int first_call = true;

  if (first_call)
  {
    current_state.start_time = 0;
    current_state.stop_time = 0;
    current_state.time_stamp = 0;
    current_state.current_button_state = button_state;
    current_state.battery_voltage = 0;
    display_time (current_state);
    first_call = false;
  }
  current_state.time_stamp = millis ();


  // OK, so we are in the loop that loops forever. If the button has been pressed, and the interupt has called the
  // function "button_press()", then the variable called "button_pressed" will be set to "true", in which
  // case we need to take action according to the new state of the button state machine.
   
  if (button_pressed)
  {
    // First thing we need to do is acknowledge that we have seen the button has been pressed, and so the 
    // state-change back to false;
    button_pressed = false;
    
    if (current_state.time_stamp - last_button_press > BUTTON_DEBOUNCE_TIME)
    {
      last_button_press = current_state.time_stamp;
      button_state ++;
      if (button_state > BUTTON_STATE_STOP)
      {
        button_state = BUTTON_STATE_START;
      }
      current_state.current_button_state = button_state;
      
      // Now we will take action depending on the new state
      switch (current_state.current_button_state)
      {
        // If the new state is BUTTON_STATE_START, we'll just store the current count of milliseconds
        case BUTTON_STATE_START:
          // current_state.start_time = 0;
          current_state.stop_time = 0;
          current_state.start_time = current_state.time_stamp;
          display_time (current_state);
          break;
          
        // If the new state is BUTTON_STATE_STOP, we'll just store the current count of milliseconds
        case BUTTON_STATE_STOP:
          current_state.stop_time = current_state.time_stamp;
          display_time (current_state);
          break;
          
        // If we get here, it means that the button is in an unknown state. This should never happen, 
        // however it is considered good practice to catch any errors. 
        default:
          error_message ("Unknown Button State");
          break;
      }
    }
  }

  if (last_battery_check + BATTERY_CHECK_INTERVAL < millis ())
  {
    // current_state.battery_voltage = read_battery_voltage ();
    display_battery_percentage ();
    last_battery_check = millis ();
  }

  // Now we just update the display, and then start the loop over again
  if (current_state.current_button_state == BUTTON_STATE_START)
  {
    display_time (current_state);
  }

}


// This function is called once over time through the main loop above. It will update the display depending 
// on the current state of the state-machine
void display_time (current_state_t current_state)
{
  unsigned long current_time;
  static char time_text [16];
  static char last_time_text [16];
  static int first_call = true;
  int x = 0;
  int y = 0;

  if (first_call)
  {
    millis_to_time (time_text, 0);
    millis_to_time (last_time_text, 0);
    first_call = false;    
  }

  // so now we need to check the current state of the state-machine so that we can update the display accordingly.
  // If the state is BUTTON_STATE_START, then we just need to find the current millisecond count, subract the start time
  // from that, and display the remainder
  // If the state is BUTTON_STATE_STOP, then the display will just be static, showing the stop_time minus the start_time.
  // If the state is BUTTON_STATE_RESET, then the display will be all zeros;
  switch (current_state.current_button_state)
  {
    case BUTTON_STATE_START:
      millis_to_time (time_text, current_state.time_stamp - current_state.start_time);
      break;

    case BUTTON_STATE_STOP:
      millis_to_time (time_text, current_state.stop_time - current_state.start_time);
      break;    

    // If the current state is BUTTON_STATE_RESET, we will just display all zeros
    // case BUTTON_STATE_RESET:
    //   strcpy (last_time_text, time_text);
    //   millis_to_time (time_text, 0);
    //   break;
      
    default:
      error_message ("Unknown Button State");
      break;
  }

  GFXfont time_font;
  // display.clearDisplay();
  switch (strlen (time_text))
  {
    case 3:
      // :00
      // Should never happen
      error_message ("String Length 3");
      break;

    case 4:
      // 0:00
      x = 15;
      y = 63;
      time_font = FreeSans24pt7b;
      // display.setFont(&FreeSans24pt7b);
      break;

    case 5:
      // 00:00
      x = 0;
      y = 63;
      time_font = FreeSans24pt7b;
      // display.setFont(&FreeSans24pt7b);
      break;

    case 6:
      // 0:00.0
      x = 0;
      y = 63;
      time_font = FreeSans24pt7b;
      // display.setFont(&FreeSans24pt7b);
      break;

    case 7:
      // 0:00:00
      x = 5;
      y = 60;
      time_font = FreeSans18pt7b;
      // display.setFont(&FreeSans18pt7b);
      break;

    case 8:
      // 00:00:00
      x = 18;
      y = 56;
      time_font = FreeSans12pt7b;
      // display.setFont(&FreeSans12pt7b);
      break;
      
    default:
      // Should never happen
      error_message ("String Length ?");
      break;

  }

  // {
  //   int tenths = (current_state.time_stamp - current_state.start_time) / 10;
  //   int pos = tenths % 128;
  //   int yy = 1;
  //   display.drawFastHLine (pos, yy++, 2, SSD1306_WHITE);
  //   display.drawFastHLine (pos, yy++, 2, SSD1306_WHITE);
  //   display.drawFastHLine (pos + 1, yy++, 2, SSD1306_WHITE);
  //   display.drawFastHLine (pos + 1, yy++, 2, SSD1306_WHITE);
  //   display.drawFastHLine (pos + 2, yy++, 2, SSD1306_WHITE);
  //   display.drawFastHLine (pos + 2, yy++, 2, SSD1306_WHITE); 
  //   display.drawFastHLine (pos + 3, yy++, 2, SSD1306_WHITE); 
  //   display.drawFastHLine (pos + 2, yy++, 2, SSD1306_WHITE); 
  //   display.drawFastHLine (pos + 2, yy++, 2, SSD1306_WHITE); 
  //   display.drawFastHLine (pos + 1, yy++, 2, SSD1306_WHITE);
  //   display.drawFastHLine (pos + 1, yy++, 2, SSD1306_WHITE);
  //   display.drawFastHLine (pos, yy++, 2, SSD1306_WHITE);
  //   display.drawFastHLine (pos, yy++, 2, SSD1306_WHITE);


  // }

  // display.drawRect (0,0,SCREEN_WIDTH,SCREEN_HEIGHT,SSD1306_WHITE);
  display.fillRect (1, 17, 128, 64, SSD1306_BLACK);
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE, SSD1306_BLACK);
  display.setCursor(x, y);
  display.setFont ((const GFXfont *) &time_font);
  display.println (String (time_text));
  display.display();
}

void display_battery_percentage ()
{
  char voltage_text [12];
  // float voltage = (float) battery.voltage () / 1000;
  int battery_percentage = battery.level ();


  sprintf (voltage_text, "%d%%", battery_percentage);
  display.fillRect (0, 0, 127, 18, SSD1306_BLACK);

  draw_battery (4, 0, 50, 16, battery_percentage);

  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE, SSD1306_BLACK);
  display.setCursor (80, 15);
  display.setFont (&FreeSans9pt7b);
  display.println (String (voltage_text));
  display.display();
}

void draw_battery (int x, int y, int battery_width, int battery_height, int battery_percentage)
{
  int i;
  display.drawRect (x, y, x + battery_width, y + battery_height, SSD1306_WHITE);
  display.drawRect (x + 1, y + 1, x + battery_width - 2, y + battery_height - 2, SSD1306_WHITE);
  for (int i = 0; i < 4; i++)
  {
    display.drawFastVLine (x + i + battery_width + 4, y + 4, y + battery_height - 8, SSD1306_WHITE);
  }

  int total_bars = battery_width - 8;
  int drawn_bars = total_bars * battery_percentage / 100;
  for (int i = 0; i < drawn_bars; i++)
  {
    display.drawFastVLine (x + i + 5, y + 4, y + battery_height - 8, SSD1306_WHITE);
  }

}

void millis_to_time (char *time_string, unsigned long milliseconds)
{
  int hours = 0;
  int minutes = 0;
  int seconds = 0;
  int decimals = 0;
  
  // The current time will be a count of milliseconds since we started, so for example, if
  // might be "7654321", but that's not very useful, so we need to convert it to hours, minutes
  // seconds and tenths of seconds
  // First we know that the last three digits are the thousandths of a second, in this exacmple
  // "321". so we will grab those three digits, convert it to tenths of a second eg "3", and then
  // remove those last three digits from the current time. This means the current time is now the 
  // number of seconds (no longer milliseconds), in this example "7654" (and we have 3 tenths
  // of a second saved).
  decimals = milliseconds % 1000;
  decimals /= 100;
  milliseconds /= 1000;

  // so now we have a current_time of 7654 seconds, which we need to convert to hours, minutes
  // and seconds. If we divide the current time by 60 (since there are 60 seconds in a minute), 
  // the result will be the number of minutes, and the remainder will be the number of seconds
  // So, 7654 / 60 gives us 127 minutes, and 34 seconds, so we'll store the 34 seconds.     
  seconds = milliseconds % 60;
  milliseconds /= 60;

  // Now the current time is the number of minutes sonce we started, in this case 127. If we 
  // divide that by 60 (since there are 60 minutes in an hour) the result will be the number
  // of hours and the remainder will be the number of minutes
  // So, 127 minutes divided by 60 leaves 2 hours, and the remainder is 7 minutes
  minutes = milliseconds % 60;
  milliseconds /= 60;  

  hours = milliseconds;
  // So now we have converted the number of milliseconds (7654321) into a more readable 2 hours,
  // 7 minutes 34 seconds and 3 tenths, and so thats how we will display it

  // Now we just need to convert those numbers into a readable string in the format "hh:mm:ss.t", 
  // In this case, that is "2:07:34.3"
  if (hours)
  {
    sprintf (time_string, "%d:%02d:%02d", hours, minutes, seconds);
  }
  else
  {
    if (minutes < 10)
    {
      sprintf (time_string, "%d:%02d.%1d", minutes, seconds, decimals);
    }
    else
    {
      sprintf (time_string, "%d:%02d", minutes, seconds);
    }
  }
}


// For good practice we will handle an error of the button being in an unknown state. 
// It should never happen, but if it does, then we will display an error message for
// 10 seconds (ie 10000 millisconds), and then reset the state machine to BUTTON_STATE_RESET
void error_message (String message)
{
  display.clearDisplay();
  display.setFont(&FreeSans9pt7b);
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(64, 0);
  display.println (message);
  display.display();
  
  delay (10000);
  display.clearDisplay();
  button_state = BUTTON_STATE_STOP;
  button_pressed = true;
  last_button_press = 0;
}

float read_battery_voltage (void)
{
  #define LAST_READS_COUNT 50
  #define BATTERY_VOLTAGE_MULTIPLIER 0.001201729

  static int last_reads [LAST_READS_COUNT] = {0};
  static int counter = 0;
  int i;
  float voltage;

  int number = analogRead (BATTERY_VOLTAGE_PIN);
  last_reads [counter++] = number;
  if (counter == LAST_READS_COUNT)
  {
    counter = 0;
  }

  number = 0;
  for (i = 0; i < LAST_READS_COUNT; i ++)
  {
    number += last_reads [i];
  }
  number /= LAST_READS_COUNT;
  voltage = (float) number * BATTERY_VOLTAGE_MULTIPLIER;
  return (voltage);
}

// This is the routine that will be called by the interupt we set up when the button is pressed. 
// We always want to keep interupt routines as short as possible, so all we do is update the state
// of the state machine, and set the flag "button_pressed" to true, so that the main loop 
// can deal with it next time around
void IRAM_ATTR button_press ()
{
  button_pressed = true;
}
